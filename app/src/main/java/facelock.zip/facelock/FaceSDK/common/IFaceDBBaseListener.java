package com.moonma.FaceSDK;

import android.graphics.Bitmap;

public interface IFaceDBBaseListener {

}