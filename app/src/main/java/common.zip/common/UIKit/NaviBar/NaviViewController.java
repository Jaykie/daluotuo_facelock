package com.moonma.common;

import android.content.Context;
import android.view.View;
import com.moonma.common.UIView;
import com.moonma.common.UIViewController;

public class NaviViewController extends UIViewController
{


}
